package com.mangatrans.vn

import android.app.Activity
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.content.res.ColorStateList
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var originalText: TextView
    private lateinit var vietnameseText: TextView
    private lateinit var translatedImage: ImageView
    private lateinit var button: Button
    private var translator: Translator? = null
    private val pink = Color.rgb(246, 85, 158)
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 16f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(65, 40, 61));
        setPadding(dp(8), dp(10), dp(8), dp(10))
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pink
        window.navigationBarColor = Color.rgb(255, 236, 246)
        val root = ScrollView(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(24))
            setBackgroundColor(Color.rgb(255, 246, 251))
        }
        root.addView(column)
        column.addView(label("🌸 MangaTrans VN — Thử thay chữ trên ảnh", 21f).apply { setTypeface(null, Typeface.BOLD) })
        column.addView(label("Bản kiểm thử độc lập: ảnh mẫu nền đen, không cần WebView. Bấm nút để OCR → dịch → che chữ Anh → vẽ chữ Việt trực tiếp lên ảnh."))
        val sample = assets.open("test_english.png").use { BitmapFactory.decodeStream(it) }
        column.addView(label("ẢNH GỐC", 17f).apply { setTypeface(null, Typeface.BOLD) })
        column.addView(ImageView(this).apply {
            setImageBitmap(sample); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(165)))
        button = Button(this).apply {
            text = "KIỂM THỬ VIỆT HÓA TRỰC TIẾP"
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(pink)
        }
        column.addView(button)
        status = label("Chưa chạy thử.")
        originalText = label("OCR: —")
        vietnameseText = label("Bản dịch: —")
        column.addView(status)
        column.addView(originalText)
        column.addView(vietnameseText)
        column.addView(label("ẢNH SAU KHI THAY CHỮ", 17f).apply { setTypeface(null, Typeface.BOLD) })
        translatedImage = ImageView(this).apply {
            setImageBitmap(sample); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        column.addView(translatedImage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(165)))
        column.addView(label("Lưu ý: ảnh thử có nền đen nên dùng che nền đen. Với ảnh truyện có tranh nền phức tạp, cần thêm bước phục hồi nền và định vị từng khung chữ; bài thử này chưa chứng minh chức năng dịch trên web.", 13f))
        setContentView(root)
        button.setOnClickListener { runTest(sample) }
    }
    private fun runTest(sample: Bitmap) {
        button.isEnabled = false
        status.text = "Đang nhận diện chữ trong ảnh mẫu ${sample.width} × ${sample.height}..."
        originalText.text = "OCR: —"
        vietnameseText.text = "Bản dịch: —"
        translatedImage.setImageBitmap(sample)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(sample, 0))
            .addOnSuccessListener { result ->
                recognizer.close()
                val source = result.text.trim()
                originalText.text = "OCR (${result.textBlocks.size} khối):\n$source"
                if (source.isBlank()) {
                    status.text = "❌ OCR không nhận diện được chữ."
                    button.isEnabled = true
                } else {
                    translateAndDraw(sample, source)
                }
            }.addOnFailureListener { e ->
                recognizer.close()
                status.text = "❌ OCR lỗi: ${e.javaClass.simpleName}: ${e.localizedMessage}"
                button.isEnabled = true
            }
    }
    private fun translateAndDraw(sample: Bitmap, source: String) {
        status.text = "OCR thành công. Đang chuẩn bị mô hình dịch Anh → Việt..."
        translator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.VIETNAMESE).build()
        val client = Translation.getClient(options)
        translator = client
        client.downloadModelIfNeeded().addOnSuccessListener {
            status.text = "Đang dịch tiếng Việt..."
            client.translate(source).addOnSuccessListener { translated ->
                vietnameseText.text = "Bản dịch máy:\n$translated"
                try {
                    val output = drawVietnamese(sample, translated)
                    translatedImage.setImageBitmap(output)
                    status.text = "✅ Đã nhận diện, dịch và vẽ chữ Việt lên ảnh mẫu."
                } catch (e: Exception) {
                    status.text = "❌ Lỗi vẽ chữ: ${e.javaClass.simpleName}: ${e.localizedMessage}"
                }
                button.isEnabled = true
            }.addOnFailureListener { e ->
                status.text = "❌ Dịch lỗi: ${e.javaClass.simpleName}: ${e.localizedMessage}"
                button.isEnabled = true
            }
        }.addOnFailureListener { e ->
            status.text = "❌ Tải mô hình lỗi: ${e.javaClass.simpleName}: ${e.localizedMessage}"
            button.isEnabled = true
        }
    }
    private fun drawVietnamese(source: Bitmap, text: String): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val width = out.width
        val height = out.height
        // The bundled test image has a black background; this is NOT general-purpose inpainting.
        val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), clearPaint)
        val content = text.trim().ifBlank { "(Không có bản dịch)" }
        val maxWidth = (width * 0.92f).toInt()
        val maxHeight = (height * 0.82f).toInt()
        var fontSize = 37f
        var layout: StaticLayout
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }
        do {
            paint.textSize = fontSize
            layout = StaticLayout.Builder.obtain(content, 0, content.length, paint, maxWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .build()
            if (layout.height <= maxHeight || fontSize <= 15f) break
            fontSize -= 1f
        } while (true)
        canvas.save()
        canvas.translate((width - maxWidth) / 2f, (height - layout.height) / 2f)
        layout.draw(canvas)
        canvas.restore()
        return out
    }
    override fun onDestroy() { translator?.close(); super.onDestroy() }
}
