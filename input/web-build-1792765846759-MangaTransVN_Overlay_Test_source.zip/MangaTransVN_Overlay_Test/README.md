# MangaTrans VN — kiểm thử thay chữ trên ảnh

Bản thử riêng, cài song song với MangaTrans VN. Ảnh tiếng Anh được đóng gói sẵn, đã kiểm thử OCR và dịch thành công trong bản thử trước.

Nhấn **KIỂM THỬ VIỆT HÓA TRỰC TIẾP**. Ứng dụng thực hiện OCR Latin bằng ML Kit, dịch Anh → Việt bằng ML Kit, sau đó tạo bitmap mới có nền đen và bản dịch tiếng Việt căn giữa trên ảnh. Xem cả văn bản OCR, bản dịch và ảnh đầu ra.

**Giới hạn quan trọng:** Đây là bản thử vẽ chữ lên ảnh mẫu có nền đen, không phải thuật toán xóa chữ trên nền tranh phức tạp. Chưa có WebView, dịch chương hoặc inpainting. OCR có thể đọc sai từ và dịch máy có thể sai. Chưa xác minh APK đã build thành công trên GitHub Actions.

## Tạo APK trên điện thoại

Tải ZIP mã nguồn này lên AndroidForge như các bản trước. Nếu biên dịch lỗi, gửi log GitHub Actions. Cài ứng dụng tên **MangaTrans Viet Hoa Test**, nhấn nút kiểm thử và gửi ảnh màn hình kết quả.
