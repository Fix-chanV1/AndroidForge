# MangaTrans VN v4 (bản thử nghiệm)

Dự án Kotlin Android, có icon launcher chibi, bộ lọc quảng cáo mở rộng và thống kê OCR/dịch thực tế thay cho thông báo hoàn tất sai.

## Tạo APK bằng điện thoại
Tải toàn bộ nội dung ZIP lên GitHub repository riêng (không tải nguyên ZIP lên như một file), vào Actions > Build MangaTrans VN APK > Run workflow. Tải artifact MangaTransVN-v4-debug khi workflow thành công.

## Giới hạn hiện tại
Chưa được biên dịch/kiểm thử trong môi trường này. OCR tiếng Hàn/Nhật cần chọn thủ công trong menu; tự nhận diện ưu tiên tiếng Anh. Dịch ảnh qua mạng cần tải model ML Kit lần đầu. Một số ảnh chống tải hoặc lazy-load sẽ thất bại. Không đảm bảo chặn mọi quảng cáo hoặc dịch được toàn bộ chương. Nếu hiện '0 ảnh đã dịch', hãy thử chọn Tiếng Anh rồi Dịch chap và xem số OCR/lỗi.

## Thay đổi chính
- Icon launcher sử dụng mascot trong dự án.
- Chặn thêm một số miền quảng cáo và phần tử quảng cáo nổi phổ biến.
- Báo số ảnh OCR thành công, số ảnh thực sự được phủ bản dịch và số ảnh lỗi.
- Giữ cơ chế dịch ảnh và giao diện pastel từ v3.
