# MangaTrans VN v2 – source preview

Ứng dụng Android WebView đọc truyện trực tuyến, giao diện hồng pastel, dịch văn bản ML Kit và OCR màn hình, chặn popup và một số chuyển hướng/quảng cáo.

## Biên dịch trên điện thoại
Tạo repository GitHub mới, tải toàn bộ **nội dung** thư mục dự án lên root repository (bao gồm `.github/workflows/build-android.yml`), vào Actions > Build MangaTrans VN APK > Run workflow. Tải artifact `MangaTransVN-v2-debug` nếu job thành công.

## Giới hạn quan trọng
- **Chưa được biên dịch/kiểm thử trên thiết bị** trong môi trường tạo này.
- OCR tự động hiện dùng Latin (Anh); cần chọn **Tiếng Hàn** hoặc **Tiếng Nhật** trong danh sách để OCR chính xác hai ngôn ngữ này.
- OCR chỉ dịch vùng đang hiển thị, nhấn lại sau khi cuộn. Chưa có dịch ảnh liên tục, không đảm bảo định vị khung thoại hoàn hảo.
- ML Kit phải tải mô hình dịch lần đầu qua Internet; nếu lỗi cần xem status ở cuối màn hình.
- Chặn popup và chuyển hướng theo heuristic, có thể chặn nhầm hoặc bỏ sót, nhất là redirect cùng tên miền.
- Không có dịch AI trả phí hay dịch ảnh bằng API bên ngoài.
