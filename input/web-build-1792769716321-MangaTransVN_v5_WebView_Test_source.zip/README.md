# MangaTrans VN v5.0 – WebView integration test

Bản thử kết nối OCR/Translate đã kiểm chứng với ảnh chụp **vùng WebView đang hiển thị**.

- Mở trang, cuộn đến chữ rõ, nhấn **Dịch ảnh**.
- **Dịch chap** hiện dùng cùng chức năng thử trên vùng nhìn thấy, CHƯA dịch cả chương.
- Ảnh Việt hóa là lớp phủ tĩnh. **Chạm ảnh** để trở về trang và cuộn tiếp; cần nhấn Dịch ảnh lại.
- Không tải lại ảnh bằng HttpURLConnection trong đường thử này.
- Tự dịch mặc định tắt để ưu tiên tốc độ.
- Vùng chữ được che bằng màu nền ước lượng, có thể làm mất chi tiết tranh.
- OCR và dịch có thể sai, và ảnh WebView có thể trống trên một số trang dùng render đặc biệt.
- Giữ bộ chặn quảng cáo và nút phát sáng của v4.2.

Dùng AndroidForge tải ZIP để thử biên dịch. Chưa xác minh biên dịch hay chạy thực tế.
