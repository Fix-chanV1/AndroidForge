plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.mangatrans.vn"; compileSdk = 35
    defaultConfig { applicationId = "com.mangatrans.vn.multipaneltest"; minSdk = 26; targetSdk = 35; versionCode = 6; versionName = "MultiPanel-Test-3" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
}
