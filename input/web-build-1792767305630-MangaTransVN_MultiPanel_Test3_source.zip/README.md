# MangaTrans VN — MultiPanel Test 3

Kiểm thử OCR, dịch và thay chữ riêng biệt ở hai vùng trong cùng một ảnh ghép từ hai ảnh truyện thật.

- Không có WebView.
- Vùng chia ảnh được định nghĩa sẵn theo hai khung, chưa phải phát hiện khung thoại tự động.
- Dịch ML Kit có thể cần tải model lần đầu.
- Nhấn BƯỚC 1, xem hai bản dịch, sửa nếu cần, nhấn BƯỚC 2.
- Chưa kiểm thử build hoặc chạy trên điện thoại.
