# MangaTrans VN v3 — bản dựng thử nghiệm

Ứng dụng Android Kotlin WebView, giao diện pastel hồng, dịch ảnh theo chương bằng ML Kit OCR (Anh/Hàn/Nhật) + ML Kit Translate, dịch văn bản HTML, chặn popup và một số tên miền quảng cáo, hạn chế tự chuyển trang khác tên miền.

## Tạo APK chỉ với điện thoại
1. Giải nén ZIP và tải **nội dung bên trong** lên thư mục gốc của repository GitHub (có `app`, `.github`, `build.gradle.kts`). GitHub web trên điện thoại có thể khó tải thư mục ẩn `.github`; hãy kiểm tra workflow thực sự có mặt.
2. Vào Actions → Build MangaTrans VN APK → Run workflow.
3. Khi có dấu tích xanh, tải artifact `MangaTransVN-v3-debug`, giải nén và cài APK.

## Lưu ý về chức năng
- Đây là mã nguồn thử nghiệm **chưa biên dịch và kiểm thử trên điện thoại**. Nếu Actions thất bại, gửi log để sửa.
- Dịch ảnh chương sẽ quét các ảnh đã được trang tải/hiển thị trong DOM tại thời điểm bấm hoặc khi mở chương. Ảnh lazy-load chưa tải, ảnh chặn truy cập, canvas, ảnh có xác thực đặc biệt có thể bị bỏ qua. Không đảm bảo dịch toàn bộ ảnh ngay lập tức.
- Dịch ảnh đang dùng OCR của ngôn ngữ đã chọn; với tự nhận diện, mặc định dùng OCR tiếng Anh. **Nên chọn tiếng Hàn hoặc Nhật thủ công** trước khi mở chương tương ứng.
- Dịch lần đầu cần tải mô hình ML Kit. Dịch theo vùng chữ có thể chậm với chương dài.
- Bộ lọc chỉ chặn các mạng quảng cáo phổ biến; không thể bảo đảm chặn mọi quảng cáo hoặc vượt Anti-AdBlock.
- Bản dịch overlay có thể che ảnh; thuật toán đặt khung thoại còn cần cải tiến.
- Không cần lưu truyện ngoại tuyến. Chỉ truy cập nội dung mà bạn được phép xem.
