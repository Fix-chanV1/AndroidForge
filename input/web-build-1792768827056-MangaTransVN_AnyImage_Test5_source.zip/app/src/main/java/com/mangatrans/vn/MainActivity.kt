package com.mangatrans.vn

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.content.res.ColorStateList
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.nl.translate.*
import kotlin.math.max
import kotlin.math.min

class MainActivity:Activity() {
    private val pink=Color.rgb(246,85,158)
    private lateinit var status:TextView
    private lateinit var original:ImageView
    private lateinit var result:ImageView
    private lateinit var regionList:LinearLayout
    private lateinit var runButton:Button
    private lateinit var language:Spinner
    private var bitmap:Bitmap?=null
    private var translator:Translator?=null
    private val blocks=mutableListOf<Pair<Rect,String>>()
    private val editors=mutableListOf<EditText>()
    private fun dp(x:Int)=(x*resources.displayMetrics.density).toInt()
    private fun label(s:String,size:Float=16f)=TextView(this).apply {text=s;textSize=size;setTextColor(Color.rgb(65,38,60));setPadding(dp(4),dp(7),dp(4),dp(7))}
    private fun button(s:String)=Button(this).apply {text=s;setTextColor(Color.WHITE);backgroundTintList=ColorStateList.valueOf(pink)}
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState);window.statusBarColor=pink
        val root=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(24));setBackgroundColor(Color.rgb(255,247,251))}
        val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll)
        root.addView(label("🌸 MangaTrans VN — Kiểm thử ảnh bất kỳ #5",22f).apply {setTypeface(null,Typeface.BOLD)})
        root.addView(label("Chọn ảnh truyện từ điện thoại → OCR tự phát hiện khối chữ → dịch → che chữ gốc và vẽ tiếng Việt lên ảnh. Không sử dụng WebView."))
        val choose=button("1 — CHỌN ẢNH TRUYỆN");root.addView(choose)
        language=Spinner(this);language.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Tiếng Anh","Tiếng Nhật","Tiếng Hàn"));root.addView(language)
        original=ImageView(this).apply {adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER};root.addView(original)
        runButton=button("2 — NHẬN DIỆN + DỊCH ẢNH");root.addView(runButton)
        status=label("Chưa chọn ảnh.");root.addView(status)
        root.addView(label("CÁC KHỐI CHỮ ĐÃ NHẬN DIỆN (có thể sửa bản dịch)",17f).apply {setTypeface(null,Typeface.BOLD)})
        regionList=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL};root.addView(regionList)
        val draw=button("3 — THAY CHỮ TRÊN ẢNH");root.addView(draw)
        root.addView(label("ẢNH SAU KHI VIỆT HÓA",18f).apply {setTypeface(null,Typeface.BOLD)})
        result=ImageView(this).apply {adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER};root.addView(result)
        root.addView(label("Giới hạn: ảnh có chữ trên nền đơn sắc sẽ cho kết quả tốt hơn. Trên nền tranh nhiều chi tiết, vùng chữ chỉ được che bằng màu nền ước lượng; chưa có AI phục hồi nền. OCR có thể nhầm từ, nên hãy sửa trong các ô trước khi vẽ. Chưa dịch trực tiếp website.",13f))
        choose.setOnClickListener {val i=Intent(Intent.ACTION_GET_CONTENT).apply {type="image/*";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,100)}
        runButton.setOnClickListener {recognize()}
        draw.setOnClickListener {drawTranslations()}
    }
    @Deprecated("Use activity result")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=100||resultCode!=RESULT_OK)return
        val uri=data?.data?:return
        try {
            val b=decode(uri)
            if(b==null){status.text="Không giải mã được ảnh.";return}
            bitmap?.recycle();bitmap=b;original.setImageBitmap(b);result.setImageBitmap(b)
            blocks.clear();editors.clear();regionList.removeAllViews()
            status.text="Đã tải ảnh ${b.width} × ${b.height}. Nhấn nhận diện + dịch."
        }catch(e:Exception){status.text="Lỗi mở ảnh: ${e.localizedMessage}"}
    }
    private fun decode(uri:Uri):Bitmap? {
        val bounds=BitmapFactory.Options().apply {inJustDecodeBounds=true}
        contentResolver.openInputStream(uri)?.use {BitmapFactory.decodeStream(it,null,bounds)}
        var sample=1
        while(max(bounds.outWidth,bounds.outHeight)/sample>2400)sample*=2
        val opts=BitmapFactory.Options().apply {inSampleSize=sample;inPreferredConfig=Bitmap.Config.ARGB_8888}
        return contentResolver.openInputStream(uri)?.use {BitmapFactory.decodeStream(it,null,opts)}
    }
    private fun recognize() {
        val b=bitmap?:run{status.text="Hãy chọn ảnh trước.";return}
        runButton.isEnabled=false;status.text="Đang nhận diện chữ..."
        blocks.clear();editors.clear();regionList.removeAllViews()
        val lang=language.selectedItemPosition
        val rec=when(lang){1->TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build());2->TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build());else->TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)}
        rec.process(InputImage.fromBitmap(b,0)).addOnSuccessListener {r->
            rec.close()
            val found=r.textBlocks.mapNotNull { t -> t.boundingBox?.let {box->Pair(Rect(box),t.text.trim())} }.filter{it.second.isNotBlank()}.sortedWith(compareBy({it.first.top},{it.first.left}))
            if(found.isEmpty()){status.text="OCR không tìm thấy chữ. Hãy thử ảnh rõ hơn hoặc đổi ngôn ngữ.";runButton.isEnabled=true;return@addOnSuccessListener}
            blocks.addAll(found.take(60))
            status.text="OCR nhận diện ${blocks.size} khối. Đang tải mô hình dịch..."
            val source=when(lang){1->TranslateLanguage.JAPANESE;2->TranslateLanguage.KOREAN;else->TranslateLanguage.ENGLISH}
            translator?.close()
            val t=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(TranslateLanguage.VIETNAMESE).build());translator=t
            t.downloadModelIfNeeded().addOnSuccessListener {translateNext(t,0)}.addOnFailureListener{e->status.text="Lỗi tải mô hình dịch: ${e.localizedMessage}";runButton.isEnabled=true}
        }.addOnFailureListener{e->rec.close();status.text="Lỗi OCR: ${e.localizedMessage}";runButton.isEnabled=true}
    }
    private fun translateNext(t:Translator,index:Int) {
        if(index>=blocks.size){status.text="✓ OCR và dịch ${blocks.size} khối. Có thể sửa bản dịch, sau đó nhấn Thay chữ.";runButton.isEnabled=true;drawTranslations();return}
        val (rect,source)=blocks[index]
        val title=label("Khối ${index+1} • (${rect.left},${rect.top}) — OCR: $source",13f);regionList.addView(title)
        val edit=EditText(this).apply {minLines=2;setTextColor(Color.BLACK);hint="Đang dịch khối ${index+1}..."};regionList.addView(edit);editors.add(edit)
        status.text="Đang dịch ${index+1}/${blocks.size}..."
        t.translate(source).addOnSuccessListener {v->edit.setText(v);translateNext(t,index+1)}.addOnFailureListener{e->edit.setText(source);title.text="Khối ${index+1} • Dịch lỗi: ${e.localizedMessage} • OCR: $source";translateNext(t,index+1)}
    }
    private fun drawTranslations() {
        val b=bitmap?:return
        if(blocks.isEmpty()||editors.size!=blocks.size){status.text="Chưa nhận diện/dịch đủ khối chữ.";return}
        val output=b.copy(Bitmap.Config.ARGB_8888,true);val canvas=Canvas(output)
        for(i in blocks.indices){val text=editors[i].text.toString().trim();if(text.isNotEmpty())drawBlock(canvas,b,blocks[i].first,text)}
        result.setImageBitmap(output)
        status.text="✓ Đã thay chữ ở ${blocks.size} khối. Kiểm tra xem chữ gốc đã được che sạch chưa."
    }
    private fun drawBlock(canvas:Canvas,b:Bitmap,rect:Rect,text:String) {
        val pad=max(9,(rect.height()*0.13f).toInt())
        val box=Rect(max(0,rect.left-pad),max(0,rect.top-pad),min(b.width,rect.right+pad),min(b.height,rect.bottom+pad))
        if(box.width()<12||box.height()<12)return
        // Ước lượng nền từ các điểm gần viền khối chữ; không phục hồi được họa tiết tranh.
        val colors=mutableListOf<Int>()
        for(y in listOf(box.top,box.bottom-1))for(x in 0 until 11){val px=box.left+(box.width()-1)*x/10;colors.add(b.getPixel(px,y))}
        for(x in listOf(box.left,box.right-1))for(y in 0 until 11){val py=box.top+(box.height()-1)*y/10;colors.add(b.getPixel(x,py))}
        val rs=colors.map{Color.red(it)}.sorted();val gs=colors.map{Color.green(it)}.sorted();val bs=colors.map{Color.blue(it)}.sorted()
        val bg=Color.rgb(rs[rs.size/2],gs[gs.size/2],bs[bs.size/2])
        val light=(Color.red(bg)*299+Color.green(bg)*587+Color.blue(bg)*114)/1000>140
        val fg=if(light)Color.BLACK else Color.WHITE
        canvas.drawRect(box,Paint().apply{color=bg})
        val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply {color=fg;typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD)}
        val w=max(8,box.width()-12);val h=max(8,box.height()-8)
        var font=min(44f,max(12f,box.height()/2.5f));lateinit var layout:StaticLayout
        while(true){paint.textSize=font;layout=StaticLayout.Builder.obtain(text,0,text.length,paint,w).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build();if(layout.height<=h||font<=8f)break;font-=1f}
        canvas.save();canvas.translate(box.left+(box.width()-w)/2f,box.top+(box.height()-layout.height)/2f);layout.draw(canvas);canvas.restore()
    }
    override fun onDestroy(){translator?.close();super.onDestroy()}
}
