# MangaTrans VN — Kiểm thử 5: ảnh bất kỳ

- Chọn ảnh từ thư viện Android (không cần cấp quyền đọc toàn bộ thư viện).
- OCR tự phát hiện các khối chữ; hỗ trợ chọn tiếng Anh, Nhật, Hàn.
- Dịch từng khối sang tiếng Việt bằng Google ML Kit (lần đầu cần Internet tải mô hình).
- Cho phép sửa bản dịch từng khối rồi che vùng OCR và vẽ chữ Việt.
- Nền được ước lượng bằng màu trung vị ở mép vùng chữ, không phải inpainting; tranh nền phức tạp có thể bị che mất.
- Không dùng WebView, không dịch trực tiếp website; chỉ là bản thử thuật toán.
- Ảnh lớn được thu nhỏ tối đa khoảng 2400px cạnh dài để tránh hết bộ nhớ.

Tải ZIP lên AndroidForge để biên dịch. Nếu lỗi, gửi nhật ký biên dịch.
