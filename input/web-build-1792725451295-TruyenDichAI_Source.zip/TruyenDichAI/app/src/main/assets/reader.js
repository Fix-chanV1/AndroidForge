(function(){
  if(window.__truyenReaderInstalled) return;
  window.__truyenReaderInstalled = true;
  const selectors=['.ads','.ad','.advertisement','[id^="google_ads"]','iframe[src*="doubleclick"]','[class*="banner-ad"]'];
  window.readerHideAds = function(){ selectors.forEach(s=>document.querySelectorAll(s).forEach(el=>el.style.setProperty('display','none','important'))); };
  window.readerCollect = function(){
    const root=document.querySelector('article,.chapter-content,.reading-content,.entry-content,.novel-content,#chapter-content,#content') || document.body;
    const nodes=[...root.querySelectorAll('p, h1, h2, h3, blockquote, li')].filter(e=>e.children.length===0 && e.innerText && e.innerText.trim().length>=12 && e.innerText.trim().length<3000).slice(0,120);
    nodes.forEach((e,i)=>e.dataset.truyenId=String(i));
    return JSON.stringify(nodes.map((e,i)=>({id:i,text:e.innerText.trim()})));
  };
  window.readerApply=function(id,translated){ const el=document.querySelector('[data-truyen-id="'+id+'"]'); if(el){ if(!el.dataset.originalText) el.dataset.originalText=el.innerText; el.innerText=translated; } };
  window.readerRestore=function(){document.querySelectorAll('[data-original-text]').forEach(el=>{el.innerText=el.dataset.originalText;delete el.dataset.originalText;});};
  window.readerImages=function(){return JSON.stringify([...document.images].map(i=>i.currentSrc||i.src).filter(u=>/^https:\/\//.test(u)).slice(0,150));};
  window.readerHideAds();
})();
