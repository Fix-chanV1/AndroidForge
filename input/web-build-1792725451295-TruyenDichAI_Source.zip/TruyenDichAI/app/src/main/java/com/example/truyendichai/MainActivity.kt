package com.example.truyendichai

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.*
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var language: Spinner
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var translator: Translator? = null
    private var generation = 0
    private var adBlock = true
    private var dark = false
    private val blockedHosts = listOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        address = EditText(this).apply { singleLine = true; hint = "https://website-truyen..."; setText("https://www.wikipedia.org/"); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
        bar.addView(address)
        bar.addView(button("Mở") { navigate() })
        root.addView(bar)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        language = Spinner(this)
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Trung → Việt", "Nhật → Việt", "Anh → Việt"))
        tools.addView(language, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(button("Dịch chữ") { translatePage() })
        tools.addView(button("Dịch ảnh") { chooseImage() })
        root.addView(tools)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("←") { if(web.canGoBack()) web.goBack() })
        controls.addView(button("→") { if(web.canGoForward()) web.goForward() })
        controls.addView(button("QC: Bật") { b -> adBlock = !adBlock; b.text = if(adBlock) "QC: Bật" else "QC: Tắt"; web.reload() })
        controls.addView(button("Nền tối") { dark = !dark; web.evaluateJavascript("document.documentElement.style.filter=${if(dark) "'invert(1) hue-rotate(180deg)'" else "''"};", null) })
        controls.addView(button("Gốc") { web.evaluateJavascript("window.readerRestore&&readerRestore();", null) })
        root.addView(controls)
        status = TextView(this).apply { text = "Chọn ngôn ngữ nguồn rồi bấm Dịch chữ hoặc Dịch ảnh"; setPadding(12,8,12,8) }
        root.addView(status)
        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                val host = uri.host?.lowercase() ?: return null
                if(adBlock && blockedHosts.any { host == it || host.endsWith(".$it") }) {
                    return WebResourceResponse("text/plain", "UTF-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                generation++
                address.setText(url ?: "")
                injectReader()
                status.text = "Đã tải trang. Chọn chức năng dịch."
            }
        }
        web.loadUrl("https://www.wikipedia.org/")
    }

    private fun button(label: String, onClick: (Button) -> Unit): Button = Button(this).apply {
        text = label; textSize = 11f; setPadding(5, 0, 5, 0); setOnClickListener { onClick(this) }
    }
    private fun button(label: String, onClick: () -> Unit): Button = button(label) { _: Button -> onClick() }
    private fun navigate() {
        var u = address.text.toString().trim()
        if(!u.startsWith("https://")) { status.text = "Chỉ hỗ trợ URL HTTPS đầy đủ để bảo vệ kết nối"; return }
        web.loadUrl(u)
    }
    private fun injectReader() {
        val script = assets.open("reader.js").bufferedReader().use { it.readText() }
        web.evaluateJavascript(script, null)
    }
    private fun sourceLanguage(): String = when(language.selectedItemPosition) {
        0 -> TranslateLanguage.CHINESE
        1 -> TranslateLanguage.JAPANESE
        else -> TranslateLanguage.ENGLISH
    }
    private fun getTranslator(onReady: (Translator) -> Unit) {
        translator?.close()
        val tr = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(sourceLanguage()).setTargetLanguage(TranslateLanguage.VIETNAMESE).build())
        translator = tr
        status.text = "Đang chuẩn bị mô hình dịch (lần đầu cần Internet)..."
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { onReady(tr) }
            .addOnFailureListener { status.text = "Không tải được mô hình dịch: ${it.localizedMessage}" }
    }
    private fun translatePage() {
        val current = generation
        injectReader()
        web.evaluateJavascript("window.readerCollect ? readerCollect() : '[]'") { result ->
            val payload = try { JSONArray(org.json.JSONTokener(result).nextValue() as String) } catch (_: Exception) { JSONArray() }
            if(payload.length()==0) { status.text="Không tìm thấy đoạn truyện dạng văn bản. Website có thể dùng bố cục khác."; return@evaluateJavascript }
            getTranslator { tr ->
                fun next(index: Int) {
                    if(current!=generation || translator !== tr) return
                    if(index>=payload.length()) { status.text="Đã dịch ${payload.length()} đoạn"; return }
                    val item = payload.getJSONObject(index)
                    val id = item.getInt("id")
                    tr.translate(item.getString("text"))
                        .addOnSuccessListener { translated ->
                            if(current==generation) web.evaluateJavascript("readerApply($id, ${JSONObject.quote(translated)});", null)
                            status.text = "Đang dịch ${index+1}/${payload.length()}"
                            next(index+1)
                        }
                        .addOnFailureListener { status.text="Lỗi đoạn ${index+1}: ${it.localizedMessage}"; next(index+1) }
                }
                next(0)
            }
        }
    }
    private fun chooseImage() {
        injectReader()
        web.evaluateJavascript("window.readerImages ? readerImages() : '[]'") { result ->
            val urls = try { JSONArray(org.json.JSONTokener(result).nextValue() as String) } catch (_: Exception) { JSONArray() }
            if(urls.length()==0) { status.text="Không tìm thấy ảnh HTTPS trên trang"; return@evaluateJavascript }
            val count = minOf(urls.length(), 40)
            val labels = (0 until count).map { "Ảnh ${it+1}: ${urls.getString(it).take(70)}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Chọn ảnh truyện cần OCR và dịch").setItems(labels) { _, which -> translateImage(urls.getString(which)) }.show()
        }
    }
    private fun translateImage(url: String) {
        status.text="Đang tải ảnh để nhận diện chữ..."
        val pageHost = android.net.Uri.parse(web.url).host ?: ""
        executor.execute {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout=10000; conn.readTimeout=15000
                conn.setRequestProperty("User-Agent", web.settings.userAgentString)
                conn.setRequestProperty("Referer", web.url ?: "")
                CookieManager.getInstance().getCookie(url)?.let { conn.setRequestProperty("Cookie", it) }
                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()
                if(bytes.size > 12_000_000) throw IllegalArgumentException("Ảnh vượt 12 MB")
                val bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: throw IllegalArgumentException("Ảnh không hợp lệ")
                main.post {
                    val recognizer = when(sourceLanguage()) {
                        TranslateLanguage.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                        TranslateLanguage.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    }
                    recognizer.process(InputImage.fromBitmap(bitmap,0))
                        .addOnSuccessListener { recognized ->
                            recognizer.close()
                            if(recognized.text.isBlank()) { status.text="Không nhận diện được chữ trong ảnh"; return@addOnSuccessListener }
                            getTranslator { tr ->
                                tr.translate(recognized.text.take(4500))
                                    .addOnSuccessListener { translated ->
                                        AlertDialog.Builder(this).setTitle("Bản dịch ảnh (OCR)")
                                            .setMessage(translated).setPositiveButton("Đóng",null).show()
                                        status.text="Đã dịch ảnh thành công"
                                    }.addOnFailureListener { status.text="Lỗi dịch ảnh: ${it.localizedMessage}" }
                            }
                        }.addOnFailureListener { recognizer.close(); status.text="Lỗi OCR: ${it.localizedMessage}" }
                }
            } catch(e: Exception) { main.post { status.text="Không tải được ảnh: ${e.localizedMessage}" } }
        }
    }
    override fun onBackPressed() { if(web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { translator?.close(); executor.shutdownNow(); web.destroy(); super.onDestroy() }
}
