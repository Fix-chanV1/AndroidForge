# Truyện Dịch AI — mã nguồn Android

## Chức năng đã có
- Trình duyệt WebView mở URL HTTPS, điều hướng trang.
- Dịch tối đa 120 đoạn văn bản/trang sang tiếng Việt bằng Google ML Kit Translate **chạy trên thiết bị**. Chọn nguồn Trung/Nhật/Anh; lần đầu cần tải mô hình.
- Chọn một ảnh từ trang, OCR Trung/Nhật/Latin rồi dịch văn bản nhận diện và hiển thị trong hộp thoại.
- Chặn một số tên miền quảng cáo phổ biến; ẩn phần tử quảng cáo theo selector.
- Chế độ nền tối đơn giản và khôi phục văn bản gốc.

## Cách biên dịch APK
1. Cài Android Studio phiên bản có hỗ trợ Android Gradle Plugin 8.7.3, JDK 17 và Android SDK Platform 35.
2. File > Open > chọn thư mục `TruyenDichAI`.
3. Chờ Gradle Sync và tải dependencies. Android Studio có thể yêu cầu cài SDK 35.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug ở `app/build/outputs/apk/debug/app-debug.apk`. Cài thử trên điện thoại Android 8.0 trở lên.
6. Để phát hành, dùng Build > Generate Signed Bundle / APK và tự ký bằng keystore của bạn.

## Giới hạn cần biết
- Đây là **mã nguồn dự án**, không phải APK đã biên dịch. Môi trường tạo dự án không có Android SDK/Gradle để xác minh build thực tế.
- OCR ảnh hiện **chỉ dịch chữ thành hộp thoại**, chưa vẽ chữ Việt đè lên bong bóng thoại. Chưa có tính năng tự động dịch tất cả ảnh trong chương.
- Dịch truyện chữ không tự động khi chuyển chương; người dùng bấm nút Dịch chữ.
- Bộ lọc quảng cáo chỉ là bộ lọc cơ bản; một số trang vẫn có quảng cáo hoặc bị ảnh hưởng khi chặn.
- Nền tối dùng bộ lọc đảo màu toàn trang, nên màu ảnh cũng có thể bị đổi.
- Dịch trang có thể thiếu văn bản khi website dùng shadow DOM, iframe hoặc các phần tử lồng nhau.
- Các ảnh cần tải được từ ứng dụng; trang chống tải ảnh có thể không hỗ trợ.
- Không có tài khoản/API key, không gửi văn bản đến API AI bên ngoài. ML Kit có thể không phù hợp văn phong tiểu thuyết như dịch vụ AI chuyên dụng.
- Chỉ nên sử dụng với nội dung bạn có quyền truy cập và tuân thủ điều khoản website.
