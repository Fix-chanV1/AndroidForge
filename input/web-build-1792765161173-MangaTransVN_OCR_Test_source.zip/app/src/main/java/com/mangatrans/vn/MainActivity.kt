package com.mangatrans.vn

import android.app.Activity
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var recognized: TextView
    private lateinit var translated: TextView
    private lateinit var button: Button
    private var translator: Translator? = null
    private val pink = Color.rgb(246, 85, 158)
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun txt(s: String, size: Float = 16f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(67, 41, 62)); setPadding(dp(12), dp(10), dp(12), dp(10))
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pink
        window.navigationBarColor = Color.rgb(255, 236, 246)
        val root = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(20)); setBackgroundColor(Color.rgb(255, 246, 251)) }
        root.addView(col)
        col.addView(txt("🌸 MangaTrans VN — Kiểm tra OCR", 22f).apply { setTypeface(null,Typeface.BOLD) })
        col.addView(txt("Bản kiểm tra độc lập: không WebView, không tải ảnh mạng. Ảnh tiếng Anh đã được đóng gói sẵn."))
        val bmp = assets.open("test_english.png").use { BitmapFactory.decodeStream(it) }
        val img = ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.BLACK) }
        col.addView(img,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(165)))
        button = Button(this).apply { text="BƯỚC 1 — NHẬN DIỆN CHỮ"; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(pink) }
        col.addView(button)
        status = txt("Chưa kiểm tra.")
        recognized = txt("Văn bản OCR: —")
        translated = txt("Bản dịch: —")
        col.addView(status); col.addView(recognized); col.addView(translated)
        col.addView(txt("Mong đợi OCR đọc được: A WAR BETWEEN DEMONS AND A UNION OF HUMANS, ELVES, BEASTS, ETC.",13f))
        col.addView(txt("Nếu OCR không đọc được, gửi ảnh màn hình kết quả. Nếu OCR thành công nhưng dịch lỗi, gửi dòng báo lỗi tải mô hình dịch.",13f))
        setContentView(root)
        button.setOnClickListener { testOcr(bmp) }
    }
    private fun testOcr(bmp: Bitmap) {
        button.isEnabled=false
        status.text="Đang chạy OCR trên ảnh mẫu ${bmp.width} × ${bmp.height}..."
        recognized.text="Văn bản OCR: —"; translated.text="Bản dịch: —"
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bmp,0))
            .addOnSuccessListener { result ->
                val text = result.text.trim()
                recognized.text = "Văn bản OCR (${result.textBlocks.size} khối):\n" + (if(text.isEmpty()) "KHÔNG NHẬN DIỆN ĐƯỢC" else text)
                recognizer.close()
                if (text.isEmpty()) { status.text="❌ OCR trống. Ảnh mẫu đã có sẵn, không phải lỗi tải ảnh website."; button.isEnabled=true }
                else { status.text="✓ OCR nhận diện được. Đang chuẩn bị mô hình dịch Anh → Việt..."; testTranslate(text) }
            }.addOnFailureListener { err ->
                status.text="❌ OCR lỗi: ${err.javaClass.simpleName}: ${err.localizedMessage}"
                recognizer.close(); button.isEnabled=true
            }
    }
    private fun testTranslate(source: String) {
        translator?.close()
        val options = TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.VIETNAMESE).build()
        val t=Translation.getClient(options);translator=t
        status.text="Đang tải/kiểm tra mô hình dịch (lần đầu cần Internet)..."
        t.downloadModelIfNeeded()
            .addOnSuccessListener {
                status.text="✓ Mô hình sẵn sàng. Đang dịch..."
                t.translate(source).addOnSuccessListener { output ->
                    translated.text="Bản dịch tiếng Việt:\n$output"
                    status.text="✅ OCR và dịch đều chạy thành công trên ảnh mẫu."
                    button.isEnabled=true
                }.addOnFailureListener { e -> status.text="❌ Dịch lỗi: ${e.javaClass.simpleName}: ${e.localizedMessage}";button.isEnabled=true }
            }.addOnFailureListener { e -> status.text="❌ Tải mô hình lỗi: ${e.javaClass.simpleName}: ${e.localizedMessage}";button.isEnabled=true }
    }
    override fun onDestroy() { translator?.close();super.onDestroy() }
}
