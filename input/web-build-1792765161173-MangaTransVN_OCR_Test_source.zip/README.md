# MangaTrans VN — OCR TEST 1

Đây là ứng dụng kiểm tra OCR và dịch độc lập, **không phải trình đọc truyện**.

- Mở app và nhấn **BƯỚC 1 — NHẬN DIỆN CHỮ**.
- Ảnh mẫu tiếng Anh được đóng gói sẵn trong `app/src/main/assets/test_english.png` (cắt từ ảnh màn hình do người dùng cung cấp).
- App hiển thị nguyên văn OCR; nếu có chữ, tự tải mô hình dịch Anh → Việt và hiển thị kết quả.
- Lần đầu tải mô hình dịch cần kết nối mạng. Không có bước tải ảnh từ Saymanhwa.
- Package khác app chính để có thể cài song song.
- ZIP này dùng với AndroidForge hoặc GitHub Actions. Chưa kiểm thử biên dịch thực tế trong môi trường này.
