# MangaTrans VN (Android / Kotlin)

## Cài đặt
1. Mở thư mục `MangaTransVN` bằng Android Studio (phiên bản hỗ trợ AGP 8.7.3, JDK 17).
2. Chờ Gradle Sync (cần Internet để tải Android Gradle Plugin, Kotlin và ML Kit).
3. Nếu dự án báo thiếu Android SDK, cài Android SDK Platform 35 qua SDK Manager.
4. Chạy trên điện thoại Android 8.0+ hoặc Build > Build APK(s).
5. Trên thiết bị: mở trang HTTPS, chọn ngôn ngữ rồi nhấn **Dịch chữ** hoặc **Dịch ảnh**.

## Giới hạn hiện tại
- Đây là mã nguồn MVP, **chưa biên dịch / kiểm thử trên Android thật** trong môi trường tạo file.
- Dịch chữ: quét tối đa 220 nút văn bản / lượt, giữ nguyên các phần tử ảnh; một số trang dùng DOM động có thể không tương thích. Dịch lại sau khi thay chương; chưa tự động dịch chương mới.
- Dịch ảnh: OCR trên **vùng màn hình đang hiển thị** và đặt hộp chữ tiếng Việt đè lên ảnh, chưa xử lý xóa chữ gốc/inpainting; hộp có thể chồng lên hình hoặc không vừa. Cuộn màn hình sẽ xóa hộp dịch.
- Khi chọn **Tự nhận diện**, OCR mặc định nhận dạng tiếng Hàn. Đối với manga Nhật hoặc ảnh chữ Anh, hãy chọn ngôn ngữ thủ công trước khi nhấn Dịch ảnh.
- Bộ lọc quảng cáo hiện tại chỉ chặn một danh sách domain ngắn, không có EasyList đầy đủ, không bảo đảm chống mọi popup, quảng cáo cùng domain hay anti-adblock.
- Điều hướng tự động khác hostname có thể bị chặn nhầm; hiện chưa có giao diện ngoại lệ / whitelist.
- ML Kit Translation tải mô hình khi dùng lần đầu, dịch chạy trên thiết bị; không cần API key. Chất lượng dịch văn học, tên riêng và xưng hô có thể chưa tốt.
- Các trang có DRM, đăng nhập, chống bot, canvas hay bảo vệ ảnh có thể không tương thích.

## Bảo mật
- Chỉ cho phép điều hướng HTTPS. Không có quyền đọc màn hình hệ thống, VPN hay Accessibility.
- Không thu thập dữ liệu đọc truyện. Cookie của trang vẫn do Android WebView quản lý.

## Nâng cấp đề xuất
- Bộ lọc EasyList/ABP và ngoại lệ theo domain.
- Nhận diện ngôn ngữ OCR tự động bằng chạy 3 bộ OCR, đánh giá chất lượng.
- Dịch ảnh theo khung thoại, bố trí lại chữ, hỗ trợ cuộn liên tục.
- Tự dịch sau khi đổi chương, cache kết quả, quản lý dấu trang.
