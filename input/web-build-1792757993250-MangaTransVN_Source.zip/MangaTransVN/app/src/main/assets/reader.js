(function(){
 if(window.__mangaReaderInstalled)return;window.__mangaReaderInstalled=true;
 window.MangaReader={
  collect:function(){
   const root=document.querySelector('article,main,.chapter-content,.reading-content,.entry-content,#chapter-content')||document.body;
   const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
   const items=[];let node;
   while((node=walker.nextNode())&&items.length<220){
    const p=node.parentElement;if(!p||!node.nodeValue||node.nodeValue.trim().length<3)continue;
    if(p.closest('script,style,noscript,nav,header,footer,button,a,textarea,input,[contenteditable]'))continue;
    if(getComputedStyle(p).display==='none'||getComputedStyle(p).visibility==='hidden')continue;
    const id='mt-'+items.length;const span=document.createElement('span');span.dataset.mtId=id;span.textContent=node.nodeValue;
    node.parentNode.replaceChild(span,node);items.push({id:id,text:span.textContent});
   }
   return JSON.stringify(items);
  },
  apply:function(id,value){const el=document.querySelector('[data-mt-id="'+id+'"]');if(el)el.textContent=value;},
  night:function(on){document.documentElement.classList.toggle('mt-night',on);},
  clearImage:function(){document.querySelectorAll('.mt-ocr-overlay').forEach(x=>x.remove())}
 };
 const s=document.createElement('style');s.textContent=`html.mt-night,html.mt-night body{background:#15171b!important;color:#e8e8e8!important}html.mt-night p,html.mt-night div,html.mt-night span{color:inherit} .mt-ocr-overlay{position:absolute;z-index:2147483640;background:rgba(255,255,245,.94);color:#111;font:14px/1.35 sans-serif;overflow:hidden;white-space:pre-wrap;pointer-events:none;border-radius:3px}`;document.head.appendChild(s);
})();
