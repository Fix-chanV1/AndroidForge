package com.mangatrans.vn

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.TextRecognition
import org.json.JSONArray
import java.net.URI

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var frame: FrameLayout
    private lateinit var overlay: FrameLayout
    private lateinit var language: Spinner
    private var night = false
    private var translator: Translator? = null
    private var translatorLang = ""
    private var modelReady = false
    private var translating = false
    private val blockedHosts = setOf("doubleclick.net","googlesyndication.com","googleadservices.com","adnxs.com","taboola.com","outbrain.com","popads.net","propellerads.com","exoclick.com","trafficjunky.net","adskeeper.com","mgid.com")
    private val suspectHosts = setOf("popads.net","propellerads.com","exoclick.com","doubleclick.net")
    private fun isBlocked(host: String): Boolean = blockedHosts.any { host == it || host.endsWith(".$it") }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun message(s: String) { runOnUiThread { status.text = s } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,245,245)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        address = EditText(this).apply { singleLine = true; setText("https://www.google.com"); hint = "Nhập địa chỉ website truyện"; inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI }
        top.addView(address, LinearLayout.LayoutParams(0, dp(52), 1f))
        top.addView(button("Mở") { openAddress() })
        root.addView(top)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(button("←") { if (web.canGoBack()) web.goBack() })
        tools.addView(button("↻") { web.reload() })
        tools.addView(button("Dịch chữ") { translatePage() })
        tools.addView(button("Dịch ảnh") { translateVisibleImage() })
        tools.addView(button("☾") { night = !night; web.evaluateJavascript("window.MangaReader&&MangaReader.night($night)", null) })
        root.addView(tools)
        language = Spinner(this)
        val languages = listOf("Tự nhận diện", "Tiếng Hàn", "Tiếng Nhật", "Tiếng Anh")
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)
        root.addView(language, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        frame = FrameLayout(this)
        web = WebView(this)
        overlay = FrameLayout(this).apply { isClickable = false; isFocusable = false }
        frame.addView(web, FrameLayout.LayoutParams(-1,-1))
        frame.addView(overlay, FrameLayout.LayoutParams(-1,-1))
        root.addView(frame, LinearLayout.LayoutParams(-1,0,1f))
        status = TextView(this).apply { text = "Sẵn sàng · dịch lần đầu cần tải mô hình qua mạng"; setPadding(dp(10),dp(5),dp(10),dp(5)); textSize = 12f }
        root.addView(status)
        setContentView(root)
        setupWeb()
        web.loadUrl("https://www.google.com")
    }
    private fun button(label: String, click: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; setPadding(dp(3),0,dp(3),0); setOnClickListener { click() }
    }
    private fun openAddress() {
        var url = address.text.toString().trim()
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://$url"
        if (!url.startsWith("https://")) { message("Chỉ hỗ trợ website HTTPS để bảo vệ dữ liệu"); return }
        web.loadUrl(url)
    }
    @Suppress("SetJavaScriptEnabled")
    private fun setupWeb() {
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            loadsImagesAutomatically = true; blockNetworkImage = false
            setSupportMultipleWindows(true); javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = true; displayZoomControls = false
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        web.setOnScrollChangeListener { _,_,_,_,_ -> overlay.removeAllViews() }
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                message("Đã chặn cửa sổ bật lên"); return false
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val host = request?.url?.host?.lowercase() ?: return null
                if (isBlocked(host)) return WebResourceResponse("text/plain", "UTF-8",  java.io.ByteArrayInputStream(ByteArray(0)))
                return null
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null || !request.isForMainFrame) return false
                val url = request.url
                if (url.scheme != "https") { message("Đã chặn liên kết không an toàn hoặc ứng dụng ngoài"); return true }
                val host = url.host?.lowercase() ?: return true
                if (isBlocked(host) || suspectHosts.any { host == it || host.endsWith(".$it") }) { message("Đã chặn trang quảng cáo"); return true }
                val current = runCatching { URI(web.url).host.orEmpty() }.getOrDefault("")
                if (!request.hasGesture() && current.isNotEmpty() && host != current && !host.endsWith(".$current")) {
                    message("Đã chặn chuyển hướng tự động sang $host"); return true
                }
                return false
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                address.setText(url ?: ""); overlay.removeAllViews(); installScript()
                message("Đã tải trang · chọn Dịch chữ hoặc Dịch ảnh")
            }
        }
    }
    private fun installScript(then: (() -> Unit)? = null) {
        val script = assets.open("reader.js").bufferedReader().use { it.readText() }
        web.evaluateJavascript(script) { if (night) web.evaluateJavascript("MangaReader.night(true)", null); then?.invoke() }
    }
    private fun selectedLang() = when (language.selectedItemPosition) { 1 -> TranslateLanguage.KOREAN; 2 -> TranslateLanguage.JAPANESE; 3 -> TranslateLanguage.ENGLISH; else -> null }
    private fun detectLang(sample: String): String {
        selectedLang()?.let { return it }
        return when {
            sample.any { it in '\uac00'..'\ud7af' } -> TranslateLanguage.KOREAN
            sample.any { it in '\u3040'..'\u30ff' } -> TranslateLanguage.JAPANESE
            else -> TranslateLanguage.ENGLISH
        }
    }
    private fun prepare(lang: String, next: () -> Unit) {
        if (translatorLang != lang || translator == null) {
            translator?.close(); translator = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(lang).setTargetLanguage(TranslateLanguage.VIETNAMESE).build())
            translatorLang = lang; modelReady = false
        }
        if (modelReady) { next(); return }
        message("Đang tải mô hình dịch ${lang.uppercase()} → VI (lần đầu cần mạng)...")
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { modelReady = true; next() }
            .addOnFailureListener { translating = false; message("Không tải được mô hình: ${it.localizedMessage}") }
    }
    private fun translatePage() {
        if (translating) { message("Đang dịch, vui lòng chờ"); return }
        overlay.removeAllViews(); translating = true
        installScript {
            web.evaluateJavascript("MangaReader.collect()") { raw ->
                val decoded = runCatching { JSONArray("[$raw]").getString(0) }.getOrDefault("[]")
                val arr = runCatching { JSONArray(decoded) }.getOrNull()
                if (arr == null || arr.length() == 0) { translating = false; message("Không tìm thấy văn bản; thử chế độ Dịch ảnh"); return@evaluateJavascript }
                val limit = minOf(arr.length(), 220)
                val sample = (0 until minOf(limit, 10)).joinToString(" ") { arr.getJSONObject(it).optString("text") }
                prepare(detectLang(sample)) {
                    message("Đang dịch $limit đoạn...")
                    fun process(i: Int) {
                        if (i >= limit) { translating = false; message("Đã dịch $limit đoạn · cuộn và bấm dịch để xử lý tiếp"); return }
                        val obj = arr.getJSONObject(i); val original = obj.optString("text")
                        translator!!.translate(original.take(4500)).addOnSuccessListener { translated ->
                            val id = org.json.JSONObject.quote(obj.getString("id")); val value = org.json.JSONObject.quote(translated)
                            web.evaluateJavascript("MangaReader.apply($id,$value)", null)
                            if (i % 12 == 0) message("Đang dịch ${i+1}/$limit")
                            process(i+1)
                        }.addOnFailureListener { process(i+1) }
                    }
                    process(0)
                }
            }
        }
    }
    private fun translateVisibleImage() {
        if (translating) { message("Đang dịch, vui lòng chờ"); return }
        if (web.width <= 0 || web.height <= 0) return
        translating = true; overlay.removeAllViews()
        // Capture only visible WebView area, not the whole chapter.
        val bmp = Bitmap.createBitmap(web.width, web.height, Bitmap.Config.ARGB_8888)
        web.draw(android.graphics.Canvas(bmp))
        val image = InputImage.fromBitmap(bmp, 0)
        val lang = selectedLang() ?: TranslateLanguage.KOREAN
        val recognizer = when (lang) {
            TranslateLanguage.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            TranslateLanguage.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        message("Đang nhận diện chữ trên phần màn hình hiện tại...")
        recognizer.process(image).addOnSuccessListener { result ->
            val blocks = result.textBlocks.filter { it.text.isNotBlank() }.take(45)
            if (blocks.isEmpty()) { translating = false; message("Không nhận diện được chữ. Hãy chọn đúng ngôn ngữ OCR."); recognizer.close(); bmp.recycle(); return@addOnSuccessListener }
            val chosen = selectedLang() ?: detectLang(result.text)
            prepare(chosen) {
                fun process(i: Int) {
                    if (i == blocks.size) { translating = false; message("Đã dịch ${blocks.size} vùng chữ trong màn hình"); recognizer.close(); bmp.recycle(); return }
                    val block = blocks[i]; val rect = block.boundingBox
                    translator!!.translate(block.text.take(4500)).addOnSuccessListener { translated ->
                        if (rect != null) addTranslationOverlay(rect, translated)
                        process(i+1)
                    }.addOnFailureListener { process(i+1) }
                }
                process(0)
            }
        }.addOnFailureListener { translating = false; message("OCR lỗi: ${it.localizedMessage}"); recognizer.close(); bmp.recycle() }
    }
    private fun addTranslationOverlay(r: Rect, translated: String) {
        val text = TextView(this).apply {
            text = translated; textSize = 12f; setTextColor(Color.BLACK)
            setBackgroundColor(Color.argb(242,255,255,244)); setPadding(dp(2),dp(1),dp(2),dp(1))
            maxLines = 12; gravity = Gravity.CENTER
        }
        val p = FrameLayout.LayoutParams(maxOf(r.width(),dp(45)), maxOf(r.height(),dp(28)))
        p.leftMargin = r.left.coerceAtLeast(0); p.topMargin = r.top.coerceAtLeast(0)
        overlay.addView(text,p)
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { translator?.close(); web.destroy(); super.onDestroy() }
}
