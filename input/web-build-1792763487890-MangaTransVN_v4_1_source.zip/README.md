# MangaTrans VN v4.1 — ưu tiên sửa OCR

## Thay đổi
- Giữ nguyên phần chặn quảng cáo đã hoạt động trên v4.
- Thêm nút **Dịch ảnh**: nhận diện chữ từ chính hình ảnh đang hiển thị trong WebView (không phải tải lại ảnh từ máy chủ). Cuộn đến đoạn truyện có chữ rồi nhấn Dịch ảnh.
- Tách thống kê lỗi: **tải lỗi / OCR trống / OCR lỗi** để xác định chính xác lý do Dịch chap không hoạt động.
- Giữ nút **Dịch chap** cũ để thử xử lý nhiều ảnh; chưa bảo đảm dịch toàn chương.

## Lưu ý quan trọng
Bản này chưa được biên dịch và kiểm thử trên máy thực. Nút Dịch ảnh chỉ xử lý phần ảnh đang nhìn thấy, là phép thử độc lập để xác minh OCR và dịch tiếng Việt hoạt động trước khi mở rộng dịch toàn chương. Cần có Internet để tải mô hình dịch ML Kit lần đầu.

## Cách tạo APK
Tải ZIP lên AndroidForge đang dùng. Nếu biên dịch lỗi, gửi log GitHub Actions để sửa.
