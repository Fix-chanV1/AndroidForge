package com.mangatrans.vn

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.content.res.ColorStateList
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var ocr: TextView
    private lateinit var editor: EditText
    private lateinit var output: ImageView
    private lateinit var original: ImageView
    private lateinit var runButton: Button
    private lateinit var redrawButton: Button
    private lateinit var selector: Spinner
    private val pink = Color.rgb(246, 85, 158)
    private var translator: Translator? = null
    private var sample: Bitmap? = null
    private var textBounds: Rect? = null
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 16f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(65, 40, 61)); setPadding(dp(8),dp(8),dp(8),dp(8))
    }
    private fun button(s: String) = Button(this).apply {
        text=s; setTextColor(Color.WHITE); backgroundTintList=ColorStateList.valueOf(pink)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pink
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(12),dp(12),dp(12),dp(30))
            setBackgroundColor(Color.rgb(255,246,251))
        }
        scroll.addView(root)
        root.addView(label("🌸 MangaTrans VN — Kiểm thử ảnh truyện thật",21f).apply { setTypeface(null,Typeface.BOLD) })
        root.addView(label("Chọn một ảnh truyện từ ảnh chụp bạn đã gửi. Ứng dụng sẽ nhận diện chữ, dịch, che riêng vùng chữ và chèn tiếng Việt tại vị trí cũ. Không cần WebView."))
        selector=Spinner(this)
        selector.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item, listOf("1. Khung thoại trắng trên tranh","2. Lời dẫn trắng trên nền đen"))
        root.addView(selector)
        root.addView(label("ẢNH GỐC",18f).apply {setTypeface(null,Typeface.BOLD)})
        original=ImageView(this).apply {adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER}
        root.addView(original,LinearLayout.LayoutParams(-1,-2))
        runButton=button("BƯỚC 1 — OCR + DỊCH + THAY CHỮ")
        root.addView(runButton)
        status=label("Chọn ảnh rồi nhấn Bước 1.")
        ocr=label("OCR: —")
        root.addView(status); root.addView(ocr)
        root.addView(label("Bản dịch tiếng Việt (có thể sửa lỗi nhận diện):"))
        editor=EditText(this).apply {minLines=2; maxLines=5; setTextColor(Color.BLACK); hint="Bản dịch sẽ xuất hiện tại đây"}
        root.addView(editor)
        redrawButton=button("BƯỚC 2 — VẼ LẠI BẰNG BẢN DỊCH ĐÃ SỬA")
        root.addView(redrawButton)
        root.addView(label("ẢNH SAU KHI THAY CHỮ",18f).apply {setTypeface(null,Typeface.BOLD)})
        output=ImageView(this).apply {adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER}
        root.addView(output,LinearLayout.LayoutParams(-1,-2))
        root.addView(label("Giới hạn: bản thử dùng nền trắng/đen ở đúng vùng chữ; chưa phục hồi tranh nằm bên dưới chữ, chưa xử lý nhiều khung thoại độc lập, chưa dịch trực tiếp trên web.",13f))
        setContentView(scroll)
        selector.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { load(position) }
        }
        runButton.setOnClickListener { runTest() }
        redrawButton.setOnClickListener {
            val bitmap=sample; val box=textBounds
            if(bitmap==null || box==null || editor.text.isBlank()) {status.text="⚠️ Hãy chạy OCR trước và nhập bản dịch.";return@setOnClickListener}
            try {output.setImageBitmap(drawLocalized(bitmap,box,editor.text.toString(),selector.selectedItemPosition)); status.text="✅ Đã vẽ lại chữ Việt vào vùng OCR trên ảnh."}
            catch(e:Exception) {status.text="❌ Lỗi vẽ: ${e.localizedMessage}"}
        }
    }
    private fun load(index:Int) {
        val filename=if(index==0) "panel_bubble.jpg" else "panel_caption.jpg"
        sample=assets.open(filename).use { BitmapFactory.decodeStream(it) }
        textBounds=null; editor.setText(""); ocr.text="OCR: —"; status.text="Đã tải ảnh mẫu ${sample!!.width} × ${sample!!.height}."
        original.setImageBitmap(sample); output.setImageBitmap(sample)
    }
    private fun runTest() {
        val bitmap=sample ?: return
        runButton.isEnabled=false
        status.text="Đang OCR ảnh ${bitmap.width} × ${bitmap.height}..."
        val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener { result ->
            recognizer.close()
            val lines=result.textBlocks.flatMap { it.lines }
            val source=result.text.trim()
            ocr.text="OCR (${result.textBlocks.size} khối, ${lines.size} dòng):\n$source"
            if(source.isBlank() || lines.isEmpty()) {status.text="❌ OCR trống. Thử ảnh còn lại.";runButton.isEnabled=true;return@addOnSuccessListener}
            // One caption / speech bubble per test image; combine all recognized line rectangles.
            val rectangles=lines.mapNotNull {it.boundingBox}
            if(rectangles.isEmpty()) {status.text="❌ OCR không trả về tọa độ.";runButton.isEnabled=true;return@addOnSuccessListener}
            val region=Rect(rectangles.minOf {it.left},rectangles.minOf {it.top},rectangles.maxOf {it.right},rectangles.maxOf {it.bottom})
            textBounds=region
            status.text="OCR thành công. Vùng chữ: $region. Đang dịch..."
            translator?.close()
            val client=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.VIETNAMESE).build())
            translator=client
            client.downloadModelIfNeeded().addOnSuccessListener {
                client.translate(source).addOnSuccessListener { translated ->
                    editor.setText(translated)
                    try {output.setImageBitmap(drawLocalized(bitmap,region,translated,selector.selectedItemPosition));status.text="✅ OCR, dịch và thay chữ xong. Bạn có thể sửa bản dịch rồi nhấn Bước 2."}
                    catch(e:Exception) {status.text="❌ Lỗi vẽ: ${e.localizedMessage}"}
                    runButton.isEnabled=true
                }.addOnFailureListener {e -> status.text="❌ Lỗi dịch: ${e.localizedMessage}";runButton.isEnabled=true}
            }.addOnFailureListener {e ->status.text="❌ Lỗi tải mô hình: ${e.localizedMessage}";runButton.isEnabled=true}
        }.addOnFailureListener {e ->recognizer.close();status.text="❌ Lỗi OCR: ${e.localizedMessage}";runButton.isEnabled=true}
    }
    private fun drawLocalized(src:Bitmap, detected:Rect, text:String, mode:Int):Bitmap {
        val result=src.copy(Bitmap.Config.ARGB_8888,true)
        val canvas=Canvas(result)
        val margin=if(mode==0) 16 else 13
        val box=Rect(max(0,detected.left-margin),max(0,detected.top-margin),min(src.width,detected.right+margin),min(src.height,detected.bottom+margin))
        // Only cover the text area. Never erase the entire image.
        val bg=if(mode==0) Color.WHITE else Color.BLACK
        val fg=if(mode==0) Color.BLACK else Color.WHITE
        val erase=Paint(Paint.ANTI_ALIAS_FLAG).apply {color=bg;style=Paint.Style.FILL}
        canvas.drawRoundRect(RectF(box), if(mode==0) 8f else 0f,if(mode==0) 8f else 0f,erase)
        val safe=text.trim().ifEmpty {"(Chưa có bản dịch)"}
        val textWidth=max(50,box.width()-10)
        val textHeight=max(25,box.height()-8)
        val p=TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {color=fg;typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD)}
        var font=min(34f,max(13f,box.height()/2.5f))
        lateinit var layout:StaticLayout
        while(true) {
            p.textSize=font
            layout=StaticLayout.Builder.obtain(safe,0,safe.length,p,textWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
            if(layout.height<=textHeight || font<=9f) break
            font-=1f
        }
        canvas.save()
        canvas.translate(box.left+(box.width()-textWidth)/2f,box.top+(box.height()-layout.height)/2f)
        layout.draw(canvas)
        canvas.restore()
        return result
    }
    override fun onDestroy() {translator?.close();super.onDestroy()}
}
