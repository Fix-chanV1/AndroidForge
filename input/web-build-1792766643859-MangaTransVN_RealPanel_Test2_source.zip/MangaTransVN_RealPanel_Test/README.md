# MangaTrans VN — Real Panel Test 2

Ứng dụng kiểm thử độc lập, không WebView. Chứa hai ảnh mẫu được cắt từ ảnh chụp truyện mà người dùng đã cung cấp: một khung thoại trắng trên tranh và một đoạn chữ trắng trên nền đen.

## Quy trình

1. Chọn ảnh mẫu.
2. Bấm BƯỚC 1 để OCR bằng ML Kit, dịch Anh-Việt bằng ML Kit và vẽ bản dịch ngay tại tọa độ OCR.
3. Sửa lỗi dịch trong ô nhập và bấm BƯỚC 2 để vẽ lại.

## Giới hạn

- Chỉ thử mỗi ảnh có một vùng lời thoại/lời dẫn. Các dòng OCR được gom thành một vùng.
- Vùng chữ được che bằng nền trắng hoặc đen; không có AI inpainting. Có thể che mất một ít nét vẽ sát chữ.
- Chưa lấy ảnh từ WebView, chưa dịch chương, chưa tự động xử lý nhiều bong bóng thoại.
- Chưa được biên dịch hay kiểm thử trên thiết bị thực.

Dùng AndroidForge tải ZIP nguồn và biên dịch. Dự án dùng Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9, Java 17.
