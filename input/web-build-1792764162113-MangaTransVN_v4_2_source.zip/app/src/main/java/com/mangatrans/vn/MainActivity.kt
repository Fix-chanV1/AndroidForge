package com.mangatrans.vn

import android.app.Activity
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import android.text.InputType
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
 private val pink=Color.rgb(247,99,158); private val ink=Color.rgb(75,44,73); private val pale=Color.rgb(255,245,250)
 private lateinit var browser:WebView; private lateinit var address:EditText; private lateinit var progress:TextView; private lateinit var bar:ProgressBar; private lateinit var action:TextView
 private var selectedMode="chapter"; private var chapterButton:TextView?=null; private var imageButton:TextView?=null; private var imageDownloadErrors=0; private var imageNoText=0; private var imageOcrErrors=0; private var translatedCount=0; private var ocrCount=0; private var failedCount=0; private var translator:Translator?=null; private var currentLanguage=""; private var ready=false; private var chapterToken=0; private var autoTranslate=true; private var dark=false; private var strongBlock=true; private var homeHost=""
 private val worker=Executors.newFixedThreadPool(2)
 private val deny=setOf("highperformanceformat.com","highestperformingformat.com","onclckads.net","onclickperformance.com","a-ads.com","hilltopads.net","juicyads.com","monetag.com","richads.com","pushhouse.net","clickadu.com","ad-maven.com","adsterra.network","doubleclick.net","googlesyndication.com","googleadservices.com","adnxs.com","taboola.com","outbrain.com","popads.net","propellerads.com","exoclick.com","mgid.com","adskeeper.com","trafficjunky.net","adsterra.com","onclicka.com")
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun shape(color:Int,r:Int=18)=GradientDrawable().apply{setColor(color);cornerRadius=dp(r).toFloat()}
 private fun label(t:String,size:Float=14f,bold:Boolean=false)=TextView(this).apply{text=t;textSize=size;setTextColor(ink);gravity=Gravity.CENTER_VERTICAL;if(bold)typeface=Typeface.DEFAULT_BOLD}
 private fun pill(t:String,background:Int,fn:()->Unit)=label(t,13f,true).apply{gravity=Gravity.CENTER;setPadding(dp(13),dp(10),dp(13),dp(10));this.background=shape(background,16);setOnClickListener{fn()}}
 private fun selectMode(mode:String){
  selectedMode=mode
  fun update(v:TextView?,active:Boolean){if(v==null)return
   v.background=GradientDrawable().apply{setColor(if(active)Color.rgb(255,134,188) else Color.WHITE);cornerRadius=dp(16).toFloat();setStroke(dp(if(active)3 else 1),if(active)Color.rgb(255,42,135) else Color.rgb(245,225,236))}
   v.elevation=dp(if(active)10 else 0).toFloat();v.setShadowLayer(if(active)dp(9).toFloat() else 0f,0f,0f,Color.rgb(255,49,144));v.setTextColor(if(active)Color.WHITE else ink)
   v.alpha=if(active)1f else .88f
  }
  update(chapterButton,mode=="chapter");update(imageButton,mode=="image")
 }
 private fun line()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
 private fun toast(t:String){runOnUiThread{progress.text=t}}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  window.statusBarColor=pink;window.navigationBarColor=pale
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(pale)}
  val header=line().apply{setPadding(dp(16),dp(10),dp(16),dp(10));background=shape(Color.rgb(255,218,233),0)}
  val mascot=ImageView(this).apply{setImageResource(R.drawable.mascot);scaleType=ImageView.ScaleType.CENTER_CROP;clipToOutline=true;background=shape(Color.WHITE,14)};header.addView(mascot,LinearLayout.LayoutParams(dp(42),dp(42)).apply{rightMargin=dp(10)})
  val brand=label("MangaTrans VN  ✿",21f,true);header.addView(brand,LinearLayout.LayoutParams(0,dp(43),1f))
  header.addView(pill("☾",Color.WHITE){dark=!dark;browser.evaluateJavascript("window.MangaV3&&MangaV3.dark($dark)",null)})
  root.addView(header)
  val addressRow=line().apply{setPadding(dp(10),dp(8),dp(10),dp(5))}
  address=EditText(this).apply{setSingleLine(true);textSize=13f;hint="Dán link chương truyện vào đây...";setTextColor(ink);setPadding(dp(12),0,dp(8),0);background=shape(Color.WHITE,16);inputType=InputType.TYPE_TEXT_VARIATION_URI;setText("https://saymanhwa.net/")}
  addressRow.addView(address,LinearLayout.LayoutParams(0,dp(48),1f))
  addressRow.addView(pill("Mở ♡",Color.rgb(255,189,216)){openUrl()},LinearLayout.LayoutParams(dp(82),dp(48)).apply{leftMargin=dp(7)})
  root.addView(addressRow)
  val toolbar=line().apply{setPadding(dp(10),dp(4),dp(10),dp(6))}
  val buttons=listOf("‹" to {if(browser.canGoBack())browser.goBack() else Unit},"↻" to {browser.reload()},"Dịch chap ✨" to {selectMode("chapter");startChapter()},"Dịch ảnh" to {selectMode("image");translateVisibleImage()},"🛡" to {strongBlock=!strongBlock;toast(if(strongBlock)"Chặn chuyển hướng: Mạnh" else "Chặn chuyển hướng: Cơ bản")})
  for((i,b) in buttons.withIndex()){val v=pill(b.first,if(i==2)Color.rgb(255,157,194) else Color.WHITE,b.second);v.textSize=if(i==2)12f else 13f;if(i==2)chapterButton=v;if(i==3)imageButton=v;toolbar.addView(v,LinearLayout.LayoutParams(0,dp(44),if(i==2)1.7f else if(i==3)1.4f else .8f).apply{if(i>0)leftMargin=dp(4)})}
  root.addView(toolbar);selectMode("chapter")
  val settings=line().apply{setPadding(dp(13),dp(1),dp(13),dp(5))}
  val languages=Spinner(this);languages.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Tự nhận diện","Tiếng Anh","Tiếng Hàn","Tiếng Nhật"));settings.addView(languages,LinearLayout.LayoutParams(0,dp(37),1f));languagePicker=languages
  val auto=Switch(this).apply{text="Tự dịch";textSize=12f;isChecked=true;setTextColor(ink);setOnCheckedChangeListener{_,v->autoTranslate=v}}
  settings.addView(auto);root.addView(settings)
  val statusRow=line().apply{setPadding(dp(14),dp(2),dp(14),dp(5))}
  action=label("📖 Đọc truyện online",12f,true);statusRow.addView(action,LinearLayout.LayoutParams(0,dp(23),1f))
  progress=label("Sẵn sàng",11f);statusRow.addView(progress);root.addView(statusRow)
  bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progressTintList=android.content.res.ColorStateList.valueOf(pink);visibility=View.GONE}
  root.addView(bar,LinearLayout.LayoutParams(-1,dp(3)))
  browser=WebView(this);root.addView(browser,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  configure();browser.loadUrl("https://saymanhwa.net/")
 }
 private lateinit var languagePicker:Spinner
 private fun host(s:String)=runCatching{URL(s).host.lowercase()}.getOrDefault("")
 private fun denied(h:String)=deny.any{h==it||h.endsWith(".$it")}
 private fun openUrl(){var u=address.text.toString().trim();if(!u.startsWith("http"))u="https://$u";if(!u.startsWith("https://")){toast("Chỉ hỗ trợ HTTPS");return};homeHost=host(u);browser.loadUrl(u);(getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken,0);address.clearFocus()}
 @Suppress("SetJavaScriptEnabled") private fun configure(){browser.settings.apply{javaScriptEnabled=true;domStorageEnabled=true;loadsImagesAutomatically=true;setSupportMultipleWindows(true);javaScriptCanOpenWindowsAutomatically=false;builtInZoomControls=true;displayZoomControls=false;mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW}
  CookieManager.getInstance().setAcceptThirdPartyCookies(browser,false)
  browser.webChromeClient=object:WebChromeClient(){override fun onCreateWindow(view:WebView?,isDialog:Boolean,isUserGesture:Boolean,resultMsg:android.os.Message?):Boolean{toast("Đã chặn popup");return false}}
  browser.webViewClient=object:WebViewClient(){
   override fun shouldInterceptRequest(view:WebView?,request:WebResourceRequest?):WebResourceResponse?{val h=request?.url?.host?.lowercase()?:return null;return if(denied(h))WebResourceResponse("text/plain","UTF-8",ByteArrayInputStream(ByteArray(0))) else null}
   override fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest?):Boolean{if(request==null||!request.isForMainFrame)return false;val u=request.url;val h=u.host?.lowercase()?:return true;if(u.scheme!="https"||denied(h)){toast("Đã chặn liên kết quảng cáo");return true};val old=host(browser.url?:"");if(strongBlock&&old.isNotBlank()&&h!=old&&!h.endsWith(".$old")&&!request.hasGesture()){toast("Đã chặn tự chuyển trang: $h");return true};return false}
   override fun onPageStarted(view:WebView?,url:String?,favicon:android.graphics.Bitmap?){chapterToken++;bar.visibility=View.VISIBLE;bar.isIndeterminate=true;toast("Đang mở trang...")}
   override fun onPageFinished(view:WebView?,url:String?){address.setText(url?:"");homeHost=host(url?:"");inject{if(autoTranslate){browser.postDelayed({if(browser.url==url)startChapter()},1100)}else{bar.visibility=View.GONE;toast("Sẵn sàng")}}}
  }
 }
 private fun inject(done:()->Unit){val js=assets.open("reader.js").bufferedReader().use{it.readText()};browser.evaluateJavascript(js){done()}}
 private fun fromJs(raw:String):JSONArray{val decoded=runCatching{JSONArray("[$raw]").getString(0)}.getOrDefault("[]");return runCatching{JSONArray(decoded)}.getOrDefault(JSONArray())}
 private fun langFrom(s:String):String=when(languagePicker.selectedItemPosition){1->TranslateLanguage.ENGLISH;2->TranslateLanguage.KOREAN;3->TranslateLanguage.JAPANESE;else->when{ s.any{it in '\uac00'..'\ud7af'}->TranslateLanguage.KOREAN;s.any{it in '\u3040'..'\u30ff'}->TranslateLanguage.JAPANESE;else->TranslateLanguage.ENGLISH}}
 private fun ensureModel(lang:String,ok:()->Unit){if(currentLanguage!=lang||translator==null){translator?.close();translator=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(lang).setTargetLanguage(TranslateLanguage.VIETNAMESE).build());currentLanguage=lang;ready=false};if(ready){ok();return};toast("Đang tải mô hình dịch $lang → VI...");translator!!.downloadModelIfNeeded().addOnSuccessListener{ready=true;ok()}.addOnFailureListener{toast("Không tải được mô hình: ${it.localizedMessage}");bar.visibility=View.GONE}}
 private fun startChapter(){translatedCount=0;ocrCount=0;failedCount=0;imageDownloadErrors=0;imageNoText=0;imageOcrErrors=0;val token=++chapterToken;bar.visibility=View.VISIBLE;bar.isIndeterminate=false;bar.progress=0;toast("Đang tìm ảnh trong chương...");inject{browser.evaluateJavascript("MangaV3.images()") {raw->val imgs=fromJs(raw);if(imgs.length()==0){toast("Không tìm thấy ảnh chương. Thử Dịch chữ.");bar.visibility=View.GONE;return@evaluateJavascript};action.text="🌸 Đang dịch ${imgs.length()} ảnh";processImage(imgs,0,token)}}}
 private fun processImage(arr:JSONArray,index:Int,token:Int){if(token!=chapterToken)return;if(index>=arr.length()){toast("Dịch $translatedCount/${arr.length()} · tải lỗi $imageDownloadErrors · OCR trống $imageNoText · OCR lỗi $imageOcrErrors");bar.visibility=View.GONE;action.text=if(translatedCount>0) "✓ Đã dịch $translatedCount ảnh" else "⚠ Chưa dịch được ảnh nào";return}
  bar.progress=index*100/arr.length();toast("Đang dịch ảnh ${index+1}/${arr.length()}")
  val obj=arr.optJSONObject(index)?:run{processImage(arr,index+1,token);return};val url=obj.optString("url");val id=obj.optString("id");if(url.isBlank()){processImage(arr,index+1,token);return}
  worker.execute{val bitmap=runCatching{val conn=URL(url).openConnection() as HttpURLConnection;conn.connectTimeout=12000;conn.readTimeout=18000;conn.setRequestProperty("User-Agent",browser.settings.userAgentString);conn.setRequestProperty("Referer",browser.url?:"https://saymanhwa.net/");CookieManager.getInstance().getCookie(url)?.let{conn.setRequestProperty("Cookie",it)};val bytes=conn.inputStream.use{it.readBytes()};conn.disconnect();val opt=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,opt);val sample=maxOf(1,maxOf(opt.outWidth/1600,opt.outHeight/2400));BitmapFactory.decodeByteArray(bytes,0,bytes.size,BitmapFactory.Options().apply{inSampleSize=sample})}.getOrNull()
   runOnUiThread{if(token!=chapterToken){bitmap?.recycle();return@runOnUiThread};if(bitmap==null){failedCount++;imageDownloadErrors++;toast("Ảnh ${index+1}: máy chủ chặn tải lại ảnh");processImage(arr,index+1,token);return@runOnUiThread};recognize(bitmap,id,arr,index,token,obj.optInt("width",bitmap.width),obj.optInt("height",bitmap.height))}
  }
 }
 private fun recognize(bmp:Bitmap,id:String,arr:JSONArray,index:Int,token:Int,originalW:Int,originalH:Int){val lang=langFrom("");val recognizer=when(lang){TranslateLanguage.JAPANESE->TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build());TranslateLanguage.KOREAN->TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build());else->TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)}
  recognizer.process(InputImage.fromBitmap(bmp,0)).addOnSuccessListener{result->val blocks=result.textBlocks.filter{it.text.isNotBlank()&&it.boundingBox!=null}.take(35);if(blocks.isEmpty()){failedCount++;imageNoText++;recognizer.close();bmp.recycle();processImage(arr,index+1,token);return@addOnSuccessListener};ocrCount++;val chosen=langFrom(result.text);ensureModel(chosen){val translated=JSONArray();fun next(i:Int){if(token!=chapterToken){recognizer.close();bmp.recycle();return};if(i==blocks.size){val payload=translated.toString();if(translated.length()>0){browser.evaluateJavascript("window.MangaV3&&MangaV3.overlay(${JSONObject.quote(id)},$payload)"){ok->if(ok=="true")translatedCount++ else failedCount++;recognizer.close();bmp.recycle();processImage(arr,index+1,token)}}else{failedCount++;recognizer.close();bmp.recycle();processImage(arr,index+1,token)};return};val b=blocks[i];translator!!.translate(b.text.take(3000)).addOnSuccessListener{t->val r=b.boundingBox!!;translated.put(JSONObject().put("x",r.left*originalW.toDouble()/bmp.width).put("y",r.top*originalH.toDouble()/bmp.height).put("w",r.width()*originalW.toDouble()/bmp.width).put("h",r.height()*originalH.toDouble()/bmp.height).put("text",t));next(i+1)}.addOnFailureListener{next(i+1)}};next(0)}
  }.addOnFailureListener{failedCount++;imageOcrErrors++;toast("OCR ảnh ${index+1}: ${it.localizedMessage}");recognizer.close();bmp.recycle();processImage(arr,index+1,token)}
 }
 private fun translateVisibleImage(){
  val token=++chapterToken
  toast("Đang chụp vùng truyện hiển thị để OCR...")
  inject{browser.evaluateJavascript("window.MangaV3&&MangaV3.visibleImage()") { raw ->
   val data=runCatching{JSONObject(JSONArray("[$raw]").getString(0))}.getOrNull()
   if(data==null || data.optString("id").isBlank()){toast("Hãy cuộn đến ảnh truyện rồi nhấn Dịch ảnh");return@evaluateJavascript}
   val width=browser.width;val height=browser.height
   if(width<=0||height<=0){toast("Trang chưa sẵn sàng");return@evaluateJavascript}
   val bmp=runCatching{Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)}.getOrNull()
   if(bmp==null){toast("Không thể tạo ảnh chụp màn hình");return@evaluateJavascript}
   browser.draw(Canvas(bmp))
   val language=langFrom("")
   val rec=when(language){
    TranslateLanguage.JAPANESE->TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
    TranslateLanguage.KOREAN->TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    else->TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
   }
   rec.process(InputImage.fromBitmap(bmp,0)).addOnSuccessListener{result->
    if(token!=chapterToken){rec.close();bmp.recycle();return@addOnSuccessListener}
    val left=data.optDouble("left");val top=data.optDouble("top");val w=data.optDouble("width");val h=data.optDouble("height")
    val iw=data.optDouble("naturalWidth");val ih=data.optDouble("naturalHeight");val screenScale=if(browser.width>0) bmp.width.toDouble()/browser.width else 1.0
    val blocks=result.textBlocks.filter{b->b.boundingBox!=null&&b.text.isNotBlank()}.take(45)
    if(blocks.isEmpty()){toast("OCR chưa nhận ra chữ trên màn hình; cần kiểm tra ảnh đầu vào hoặc thử khung chữ khác.");rec.close();bmp.recycle();return@addOnSuccessListener}
    val chosen=langFrom(result.text)
    ensureModel(chosen){
     val output=JSONArray()
     fun next(i:Int){
      if(token!=chapterToken){rec.close();bmp.recycle();return}
      if(i==blocks.size){
       browser.evaluateJavascript("MangaV3.overlay(${JSONObject.quote(data.optString("id"))},${output})"){ok->
        toast(if(ok=="true")"Đã dịch ${output.length()} khung chữ trên ảnh đang xem" else "Không thể gắn bản dịch lên ảnh")
        rec.close();bmp.recycle()
       }
       return
      }
      val block=blocks[i];val r=block.boundingBox!!
      translator!!.translate(block.text.take(2500)).addOnSuccessListener{translated->
       output.put(JSONObject().put("x",((r.left/screenScale-left)/w*iw).coerceAtLeast(0.0)).put("y",((r.top/screenScale-top)/h*ih).coerceAtLeast(0.0)).put("w",(r.width()/screenScale/w*iw)).put("h",(r.height()/screenScale/h*ih)).put("text",translated))
       next(i+1)
      }.addOnFailureListener{next(i+1)}
     }
     next(0)
    }
   }.addOnFailureListener{toast("OCR ảnh hiển thị thất bại: ${it.localizedMessage}");rec.close();bmp.recycle()}
  }}
 }
 private fun translateText(){val token=++chapterToken;inject{browser.evaluateJavascript("MangaV3.text()") {raw->val a=fromJs(raw);if(a.length()==0){toast("Không có chữ HTML; hãy dùng Dịch chap");return@evaluateJavascript};ensureModel(langFrom((0 until minOf(5,a.length())).joinToString(" "){a.optJSONObject(it)?.optString("text")?:""})){fun next(i:Int){if(token!=chapterToken)return;if(i>=a.length()){toast("Đã dịch ${a.length()} đoạn");return};val o=a.optJSONObject(i)?:return;translator!!.translate(o.optString("text").take(4000)).addOnSuccessListener{t->browser.evaluateJavascript("MangaV3.applyText(${JSONObject.quote(o.optString("id"))},${JSONObject.quote(t)})",null);next(i+1)}.addOnFailureListener{next(i+1)}};next(0)}}}}
 override fun onBackPressed(){if(browser.canGoBack())browser.goBack() else super.onBackPressed()}
 override fun onDestroy(){chapterToken++;translator?.close();worker.shutdownNow();browser.destroy();super.onDestroy()}
}
