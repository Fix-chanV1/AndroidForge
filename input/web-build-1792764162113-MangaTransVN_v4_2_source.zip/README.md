# MangaTrans VN v4.2 — chế độ dịch được chọn phát sáng

- Nút **Dịch chap** và **Dịch ảnh** có trạng thái lựa chọn độc lập: nút đang chọn nền hồng đậm, viền hồng và đổ bóng; khi đổi chế độ, hiệu ứng chuyển theo.
- Giữ nguyên quy tắc chặn quảng cáo của v4.1.
- Sửa lỗi nút Dịch ảnh có thể gọi JavaScript trước khi reader.js được nạp.
- Điều chỉnh bước lọc vùng OCR để tránh loại nhầm toàn bộ chữ vì tọa độ WebView và bitmap khác nhau.
- Đây là bản sửa thử nghiệm, **chưa xác nhận OCR hoặc dịch toàn chương hoạt động thành công trên Saymanhwa**. Tải ảnh chương riêng qua HTTP vẫn có thể thất bại.

Tải file ZIP lên AndroidForge để build APK. Nếu báo lỗi, gửi nhật ký build.
