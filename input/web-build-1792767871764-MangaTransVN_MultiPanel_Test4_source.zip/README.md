# MangaTrans VN — MultiPanel Test 4

Kiểm thử hai vùng chữ trên ảnh ghép thật. OCR và dịch ML Kit chạy như bản 3. Bản 4 cải thiện vùng che chữ lời dẫn nền đen bằng một hình chữ nhật cố định (x=20..671, y=675..806 trong ảnh mẫu 691×1038), phủ cả viền sáng. Tự điều chỉnh kích thước chữ theo khung.

Nút "GỢI Ý BIÊN TẬP CHO ẢNH MẪU" điền hai câu dịch được viết sẵn để kiểm thử chất lượng trình bày. Đây không phải đầu ra tự động của bộ dịch; có thể sửa thủ công.

Không có WebView. Chưa có phát hiện khung thoại tự động, inpainting hoặc dịch ảnh trên website. Chưa biên dịch hay thử trên máy thật.
