package com.mangatrans.vn

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.content.res.ColorStateList
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val pink=Color.rgb(246,85,158)
    private lateinit var status:TextView
    private lateinit var detail:TextView
    private lateinit var imageOriginal:ImageView
    private lateinit var imageResult:ImageView
    private lateinit var editor1:EditText
    private lateinit var editor2:EditText
    private lateinit var start:Button
    private lateinit var redraw:Button
    private lateinit var suggestion:Button
    private var translator:Translator?=null
    private var source:Bitmap?=null
    private val regions=mutableListOf<Rect>()
    private val textRects=mutableListOf<Rect>()
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun txt(v:String,size:Float=16f)=TextView(this).apply {text=v;textSize=size;setTextColor(Color.rgb(60,35,55));setPadding(dp(5),dp(8),dp(5),dp(8))}
    private fun btn(v:String)=Button(this).apply {text=v;setTextColor(Color.WHITE);backgroundTintList=ColorStateList.valueOf(pink)}
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=pink
        val root=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(12),dp(12),dp(24));setBackgroundColor(Color.rgb(255,246,251))}
        val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll)
        root.addView(txt("🌸 MangaTrans VN — Kiểm thử 4",23f).apply {setTypeface(null,Typeface.BOLD)})
        root.addView(txt("Kiểm thử hai vùng chữ độc lập trong một ảnh ghép từ hai khung truyện thật. Không sử dụng WebView hay mạng để tải ảnh."))
        imageOriginal=ImageView(this).apply {adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER}
        root.addView(txt("ẢNH GỐC",18f));root.addView(imageOriginal)
        start=btn("BƯỚC 1 — OCR + DỊCH 2 VÙNG");root.addView(start)
        status=txt("Chưa chạy thử.");detail=txt("OCR: —")
        root.addView(status);root.addView(detail)
        root.addView(txt("Bản dịch vùng 1 (khung thoại trắng):"))
        editor1=EditText(this).apply {minLines=2;setTextColor(Color.BLACK);hint="Chờ dịch vùng 1"};root.addView(editor1)
        root.addView(txt("Bản dịch vùng 2 (lời dẫn nền đen):"))
        editor2=EditText(this).apply {minLines=2;setTextColor(Color.BLACK);hint="Chờ dịch vùng 2"};root.addView(editor2)
        suggestion=btn("GỢI Ý BIÊN TẬP CHO ẢNH MẪU");root.addView(suggestion)
        suggestion.setOnClickListener {
            editor1.setText("Haiz... Đúng là một cuộc đời bất hạnh.")
            editor2.setText("Một cuộc chiến giữa loài quỷ và liên minh gồm con người, yêu tinh, người thú cùng các chủng tộc khác.")
            status.text="Đã điền gợi ý biên tập cho 2 câu mẫu. Nhấn Bước 2 để vẽ lại."
        }
        redraw=btn("BƯỚC 2 — THAY CHỮ CẢ 2 VÙNG");root.addView(redraw)
        root.addView(txt("ẢNH ĐÃ VIỆT HÓA",18f))
        imageResult=ImageView(this).apply {adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER};root.addView(imageResult)
        root.addView(txt("Bản 4: vùng xóa chữ lời dẫn nền đen được xác định riêng cho ảnh mẫu để xóa cả viền sáng. Gợi ý biên tập là câu mẫu viết sẵn, không phải kết quả dịch tự động. Chưa tự phát hiện vùng chữ, chưa phục hồi nền phức tạp và chưa dịch website.",13f))
        source=assets.open("two_panels.jpg").use {BitmapFactory.decodeStream(it)}
        imageOriginal.setImageBitmap(source);imageResult.setImageBitmap(source)
        val aHeight=420;val sep=28;val total=source!!.height
        regions.add(Rect(0,0,source!!.width,aHeight))
        regions.add(Rect(0,aHeight+sep,source!!.width,total))
        start.setOnClickListener {runOCR()}
        redraw.setOnClickListener {redrawImages()}
    }
    private fun runOCR() {
        val bmp=source ?:return
        start.isEnabled=false;status.text="Đang nhận diện vùng 1/2...";detail.text="OCR: —";textRects.clear()
        val texts=mutableListOf<String>()
        fun scan(index:Int) {
            if(index>=regions.size) {translateAll(texts);return}
            val roi=regions[index]
            val crop=Bitmap.createBitmap(bmp,roi.left,roi.top,roi.width(),roi.height())
            val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(crop,0)).addOnSuccessListener {res ->
                recognizer.close();crop.recycle()
                val rects=res.textBlocks.flatMap{it.lines}.mapNotNull{it.boundingBox}
                if(res.text.isBlank() || rects.isEmpty()) {status.text="❌ OCR vùng ${index+1} không nhận diện được chữ.";start.isEnabled=true;return@addOnSuccessListener}
                val bound=Rect(rects.minOf{it.left}+roi.left,rects.minOf{it.top}+roi.top,rects.maxOf{it.right}+roi.left,rects.maxOf{it.bottom}+roi.top)
                textRects.add(bound);texts.add(res.text.trim())
                status.text="OCR vùng ${index+1}/2 thành công. Đang xử lý vùng tiếp..."
                scan(index+1)
            }.addOnFailureListener{e ->recognizer.close();crop.recycle();status.text="❌ OCR vùng ${index+1}: ${e.localizedMessage}";start.isEnabled=true}
        }
        scan(0)
    }
    private fun translateAll(texts:List<String>) {
        detail.text="OCR vùng 1:\n${texts[0]}\n\nOCR vùng 2:\n${texts[1]}"
        status.text="Đã OCR 2 vùng. Đang tải mô hình dịch nếu cần..."
        translator?.close()
        val t=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.VIETNAMESE).build())
        translator=t
        t.downloadModelIfNeeded().addOnSuccessListener {
            t.translate(texts[0]).addOnSuccessListener {first ->
                editor1.setText(first)
                t.translate(texts[1]).addOnSuccessListener {second ->
                    editor2.setText(second);status.text="✅ OCR và dịch cả 2 vùng thành công. Đã thay chữ trên ảnh mẫu."
                    redrawImages();start.isEnabled=true
                }.addOnFailureListener{e ->status.text="❌ Dịch vùng 2: ${e.localizedMessage}";start.isEnabled=true}
            }.addOnFailureListener{e ->status.text="❌ Dịch vùng 1: ${e.localizedMessage}";start.isEnabled=true}
        }.addOnFailureListener{e ->status.text="❌ Tải mô hình dịch: ${e.localizedMessage}";start.isEnabled=true}
    }
    private fun redrawImages() {
        val bmp=source ?:return
        if(textRects.size!=2 || editor1.text.isBlank() || editor2.text.isBlank()) {status.text="⚠️ Cần OCR và dịch đủ 2 vùng trước.";return}
        val result=bmp.copy(Bitmap.Config.ARGB_8888,true)
        val canvas=Canvas(result)
        paintText(canvas,textRects[0],editor1.text.toString(),Color.WHITE,Color.BLACK)
        // Với ảnh mẫu, lời dẫn nằm trên nền đen. Xóa toàn bộ dải chữ,
        // bao gồm viền phát sáng mà OCR thường không bao phủ hết.
        val captionZone=Rect(20,675,671,806)
        paintText(canvas,captionZone,editor2.text.toString(),Color.BLACK,Color.WHITE,true)
        imageResult.setImageBitmap(result)
        status.text="✅ Đã thay chữ tiếng Việt riêng biệt trong cả 2 vùng."
    }
    private fun paintText(canvas:Canvas,found:Rect,value:String,bg:Int,fg:Int,exactBox:Boolean=false) {
        val src=source ?:return
        val margin=if(bg==Color.WHITE) 15 else 13
        val box=if(exactBox) Rect(found) else Rect(max(0,found.left-margin),max(0,found.top-margin),min(src.width,found.right+margin),min(src.height,found.bottom+margin))
        canvas.drawRoundRect(RectF(box),if(bg==Color.WHITE) 8f else 0f,if(bg==Color.WHITE) 8f else 0f,Paint(Paint.ANTI_ALIAS_FLAG).apply {color=bg})
        val safe=value.trim();val width=max(40,box.width()-24);val height=max(20,box.height()-12)
        val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply {color=fg;typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD)}
        var font=min(if(exactBox) 30f else 34f,max(12f,box.height()/3.1f));lateinit var layout:StaticLayout
        while(true) {
            paint.textSize=font
            layout=StaticLayout.Builder.obtain(safe,0,safe.length,paint,width).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
            if(layout.height<=height || font<=10f)break
            font-=1f
        }
        canvas.save();canvas.translate(box.left+(box.width()-width)/2f,box.top+(box.height()-layout.height)/2f);layout.draw(canvas);canvas.restore()
    }
    override fun onDestroy(){translator?.close();super.onDestroy()}
}
